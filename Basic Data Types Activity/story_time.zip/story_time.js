// TODO: Create 4-String variables to introduce develop your story.
// YOUR CODE GOES HERE


// TODO: Create 3-String variables to set the time period of your story or discuss other number elements.
// YOUR CODE GOES HERE


// TODO: Create 1-Array variable to show a collection of items your character might have.
// YOUR CODE GOES HERE


// TODO: Create 1-Boolean variable to demonstrate a true or false scenario.
// YOUR CODE GOES HERE


// TODO: Print your story to the console.
// YOUR CODE GOES HERE
let greetings = "Welcome to Canterlot!"
let name = "Twilight"
let title = "The Grand Galloping Gala";
let WorldName = "Equestria";

let anniversary = 13;
let year = 2025;
let century = 20;

let items = ["crown", "microphone", "JournalOfFriendship", "fireworks"]

let hasMic = true;

console.log(items[1]  +  " feedback")
console.log(greetings + " It has been a long journey since the very first Grand Galloping Gala, and I remember how much we have made this festival a better place.");
console.log("Thank you all for putting in your hard work to make this the best party we have had in the last " + anniversary + " years")
console.log("Without further ado, have fun tonight!")
console.log("[ponies chatting]")
console.log("[Spike] We are going to set up a fireworks display after four hours, so stay partying!")
console.log("TWO HOURS LATER")
console.log("[" + name + "] Because it is " + title + "'s " + anniversary + "th anniversary, us unicorns wanted to enchant a slideshow of all the great times we have had at the Gala, and how they have improved over time.")
console.log("[as slideshow plays] [Discord] That's me!")
console.log("[pony] You look so good in that.")
console.log("[applause after slideshow ends]")
console.log("Look up at the sky because it is time for the fireworks display. We couldn't have made it to our " + anniversary + "th anniversary of this party without you all.")

